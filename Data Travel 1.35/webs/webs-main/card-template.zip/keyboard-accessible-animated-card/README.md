# Keyboard accessible animated card

A Pen created on CodePen.io. Original URL: [https://codepen.io/ItsCrisDiaz/pen/NWgOZjX](https://codepen.io/ItsCrisDiaz/pen/NWgOZjX).

